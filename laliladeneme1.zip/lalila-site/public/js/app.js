document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelector(".nav-links");
  if (menuToggle && navLinks) {
    menuToggle.addEventListener("click", () => {
      navLinks.classList.toggle("active");
    });
  }

  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (e) => {
      const href = anchor.getAttribute("href");
      if (href && href.length > 1) {
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          target.scrollIntoView({ behavior: "smooth" });
        }
      }
    });
  });

  const slides = document.querySelectorAll(".hero-slider .slide");
  if (slides.length > 1) {
    let current = 0;
    setInterval(() => {
      slides[current].classList.remove("active");
      current = (current + 1) % slides.length;
      slides[current].classList.add("active");
    }, 4500);
  }

  const FAV_KEY = "lalila_favorites_v1";
  const getFavorites = () => {
    try {
      return JSON.parse(localStorage.getItem(FAV_KEY) || "[]");
    } catch {
      return [];
    }
  };
  const saveFavorites = (list) => {
    localStorage.setItem(FAV_KEY, JSON.stringify(list));
    updateFavUI();
  };
  const updateFavUI = () => {
    const favs = getFavorites();
    document.querySelectorAll(".favorite-btn .badge, #favCount").forEach((el) => {
      el.textContent = String(favs.length);
    });
    document.querySelectorAll(".fav-toggle-btn").forEach((btn) => {
      const id = btn.getAttribute("data-fav-id");
      const active = favs.includes(id);
      btn.textContent = active ? "❤️ Favoride" : "🤍 Favori";
    });
  };

  document.querySelectorAll(".fav-toggle-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-fav-id");
      if (!id) return;
      const favs = getFavorites();
      if (favs.includes(id)) {
        saveFavorites(favs.filter((item) => item !== id));
      } else {
        saveFavorites([...favs, id]);
      }
    });
  });

  const categoryBtns = document.querySelectorAll("#categoryFilters .filter-btn");
  const searchInput = document.getElementById("catalogSearch");
  const lightFilter = document.getElementById("lightFilter");
  const productCards = document.querySelectorAll("#productsGrid .product-card");
  const statusEl = document.getElementById("catalogStatus");

  let selectedCategory = "all";
  let onlyFavorites = false;

  const filterProducts = () => {
    if (!productCards.length) return;
    const query = (searchInput?.value || "").trim().toLowerCase();
    const light = lightFilter?.value || "all";
    const favs = getFavorites();
    let visibleCount = 0;

    productCards.forEach((card) => {
      const cat = card.getAttribute("data-category") || "";
      const cardLight = card.getAttribute("data-light") || "";
      const name = (card.getAttribute("data-name") || card.textContent || "").toLowerCase();
      const id = card.getAttribute("data-id") || "";

      const matchCat = selectedCategory === "all" || cat === selectedCategory;
      const matchLight = light === "all" || cardLight === light;
      const matchQuery = !query || name.includes(query);
      const matchFav = !onlyFavorites || favs.includes(id);

      const show = matchCat && matchLight && matchQuery && matchFav;
      card.style.display = show ? "" : "none";
      if (show) visibleCount++;
    });

    if (statusEl) {
      statusEl.textContent = `${visibleCount} ürün listeleniyor${onlyFavorites ? " (Favoriler filtresi aktif)" : ""}.`;
    }
  };

  categoryBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      onlyFavorites = false;
      categoryBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      selectedCategory = btn.getAttribute("data-category") || "all";
      filterProducts();
    });
  });

  searchInput?.addEventListener("input", filterProducts);
  lightFilter?.addEventListener("change", filterProducts);

  const favBtn = document.getElementById("catalogFavoritesBtn");
  favBtn?.addEventListener("click", (e) => {
    e.preventDefault();
    onlyFavorites = !onlyFavorites;
    filterProducts();
  });

  updateFavUI();
  filterProducts();
});

/* ===== Tema, WhatsApp, mobil menü ===== */
(() => {
  // WhatsApp numaranı buraya yaz (başında + olmadan, ülke koduyla). Örnek: 905551234567
  const WHATSAPP_NUMBER = "90XXXXXXXXXX";
  const WHATSAPP_MESSAGE = "Merhaba, perde sistemleri hakkında bilgi almak istiyorum.";

  const THEME_KEY = "lalila_theme";
  const root = document.documentElement;
  const applyTheme = (t) => {
    root.setAttribute("data-theme", t);
    const b = document.querySelector(".theme-toggle");
    if (b) {
      b.textContent = t === "dark" ? "☀️" : "🌙";
      b.setAttribute("aria-label", t === "dark" ? "Açık moda geç" : "Karanlık moda geç");
    }
  };
  const current = () => root.getAttribute("data-theme") || "light";

  const navbar = document.querySelector(".navbar");
  if (navbar) {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "theme-toggle";
    const anchor = navbar.querySelector(".menu-toggle");
    anchor ? navbar.insertBefore(btn, anchor) : navbar.appendChild(btn);
    btn.addEventListener("click", () => {
      const next = current() === "dark" ? "light" : "dark";
      try { localStorage.setItem(THEME_KEY, next); } catch {}
      applyTheme(next);
    });
  }
  applyTheme(current());

  const waUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(WHATSAPP_MESSAGE)}`;
  const wa = document.createElement("a");
  wa.className = "whatsapp-float";
  wa.href = waUrl;
  wa.target = "_blank";
  wa.rel = "noopener";
  wa.setAttribute("aria-label", "WhatsApp ile yazın");
  wa.innerHTML = '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M16.003 3C8.83 3 3 8.83 3 16c0 2.29.6 4.52 1.74 6.49L3 29l6.7-1.72A12.94 12.94 0 0 0 16 29c7.17 0 13-5.83 13-13S23.17 3 16.003 3zm0 23.7c-1.94 0-3.84-.52-5.5-1.5l-.4-.23-3.98 1.02 1.06-3.88-.26-.4A10.66 10.66 0 0 1 5.3 16c0-5.9 4.8-10.7 10.7-10.7S26.7 10.1 26.7 16 21.9 26.7 16 26.7zm5.86-8c-.32-.16-1.9-.94-2.2-1.04-.3-.1-.5-.16-.72.16-.22.32-.84 1.04-1.03 1.26-.19.22-.38.24-.7.08-.32-.16-1.36-.5-2.58-1.6-.95-.85-1.6-1.9-1.78-2.22-.19-.32-.02-.5.14-.66.14-.14.32-.38.48-.57.16-.19.22-.32.32-.54.1-.22.05-.4-.03-.57-.08-.16-.72-1.74-.99-2.38-.26-.62-.52-.54-.72-.55h-.6c-.22 0-.57.08-.87.4-.3.32-1.14 1.12-1.14 2.72s1.17 3.16 1.33 3.38c.16.22 2.3 3.5 5.56 4.92.78.34 1.38.54 1.86.7.78.25 1.5.21 2.06.13.63-.09 1.9-.78 2.17-1.53.27-.75.27-1.4.19-1.53-.08-.13-.3-.21-.62-.37z"/></svg>';
  document.body.appendChild(wa);
  document.querySelectorAll('a[href^="https://wa.me/"]').forEach((a) => {
    if (a !== wa) {
      a.href = waUrl;
      a.textContent = "+" + WHATSAPP_NUMBER;
    }
  });

  // Mobilde menüden bir linke tıklayınca menüyü kapat
  document.querySelectorAll(".nav-links a").forEach((a) => {
    a.addEventListener("click", () => {
      document.querySelector(".nav-links")?.classList.remove("active");
    });
  });
})();
